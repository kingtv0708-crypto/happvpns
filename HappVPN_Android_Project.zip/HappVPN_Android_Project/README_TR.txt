HAPP VPN - ANDROID STUDIO PROJESİ

Bu ZIP dosyası Android Studio proje taslağı içerir. Derlenmiş APK şu anda ZIP'in içinde değildir.
Uygulama yalnızca arayüz demosudur; gerçek VPN bağlantısı kurmaz.

APK oluşturma (Android Studio):
1. ZIP dosyasını çıkarın ve HappVPN klasörünü Android Studio ile açın.
2. Gradle eşitlemesi tamamlanınca Build > Build Bundle(s) / APK(s) > Build APK(s) seçin.
3. APK genellikle app/build/outputs/apk/debug/app-debug.apk yolunda oluşur.

GitHub Actions ile derleme:
1. ZIP'i çıkarıp içeriğini yeni bir GitHub deposuna yükleyin.
2. Actions sekmesini açın ve "Build Happ VPN APK" iş akışını çalıştırın (Run workflow).
3. İşlem bitince HappVPN-debug-apk adlı artifact'i indirin; içinde app-debug.apk bulunur.

Gerçek VPN bağlantısı için güvenilir bir VPN sunucusu ve uygun protokol/istemci entegrasyonu gerekir.
Bu demo, internet trafiğini tünellemez ve gerçek VPN servisi değildir.
