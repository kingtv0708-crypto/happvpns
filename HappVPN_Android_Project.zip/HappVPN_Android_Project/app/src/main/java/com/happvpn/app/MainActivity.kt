package com.happvpn.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private var connected = false
    private lateinit var status: TextView
    private lateinit var connectButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val navy = Color.rgb(5, 11, 34)
        val cyan = Color.rgb(0, 215, 245)
        val white = Color.WHITE

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 36, 28, 36)
            setBackgroundColor(navy)
        }

        val title = TextView(this).apply {
            text = "Happ VPN"
            textSize = 34f
            setTextColor(white)
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            gravity = Gravity.CENTER
        }

        val subtitle = TextView(this).apply {
            text = "Gizliliğin için sade bir arayüz"
            textSize = 16f
            setTextColor(Color.rgb(170, 190, 220))
            gravity = Gravity.CENTER
            setPadding(0, 10, 0, 42)
        }

        val shield = TextView(this).apply {
            text = "🛡️"
            textSize = 72f
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 22)
        }

        status = TextView(this).apply {
            text = "Durum: Bağlı değil"
            textSize = 18f
            setTextColor(white)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 24)
        }

        connectButton = Button(this).apply {
            text = "BAĞLAN"
            textSize = 18f
            setTextColor(navy)
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(cyan))
            setOnClickListener {
                connected = !connected
                if (connected) {
                    status.text = "Durum: Demo modu açık"
                    text = "BAĞLANTIYI KAPAT"
                } else {
                    status.text = "Durum: Bağlı değil"
                    text = "BAĞLAN"
                }
            }
        }

        val note = TextView(this).apply {
            text = "Bu sürüm arayüz demosudur; gerçek VPN bağlantısı kurmaz. Gerçek bağlantı için VPN protokolü ve sunucu yapılandırması eklenmelidir."
            textSize = 13f
            setTextColor(Color.rgb(170, 190, 220))
            gravity = Gravity.CENTER
            setPadding(0, 34, 0, 0)
        }

        root.addView(title, LinearLayout.LayoutParams(-1, -2))
        root.addView(subtitle, LinearLayout.LayoutParams(-1, -2))
        root.addView(shield, LinearLayout.LayoutParams(-1, -2))
        root.addView(status, LinearLayout.LayoutParams(-1, -2))
        root.addView(connectButton, LinearLayout.LayoutParams(-1, -2))
        root.addView(note, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)
    }
}
